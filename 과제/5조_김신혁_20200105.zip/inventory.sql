-- --------------------------------------------------------
-- 호스트:                          192.168.56.101
-- 서버 버전:                        10.4.11-MariaDB - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- inventory 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `inventory` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `inventory`;

-- 테이블 inventory.inventoryitem 구조 내보내기
CREATE TABLE IF NOT EXISTS `inventoryitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `brand` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `item` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 테이블 데이터 inventory.inventoryitem:~12 rows (대략적) 내보내기
/*!40000 ALTER TABLE `inventoryitem` DISABLE KEYS */;
INSERT INTO `inventoryitem` (`id`, `category`, `brand`, `item`, `price`, `amount`, `total`) VALUES
	(4, '전자기기', '삼성', '냉장고', 2500000, 8, NULL),
	(5, '전자기기', 'LG', '냉장고', 2450000, 11, NULL),
	(11, '식품', '제주', '초콜릿', 3000, 103, NULL),
	(12, '식품', '크라운', '초콜릿', 4000, 90, NULL),
	(14, '생필품', '노브랜드', '손톱깎이', 2100, 6, NULL),
	(15, '생필품', '노브랜드', '빗자루', 3300, 2, NULL),
	(16, '생필품', '다이소', '빗자루', 1300, 1, NULL),
	(17, '생필품', '다이소', '빨래건조대', 8650, 1, NULL),
	(25, '식품', '청정원', '두부', 2000, 4, NULL),
	(26, '식품', '제주', '한라봉', 15000, 199, NULL),
	(27, '식품', '제주', '한라봉', 999, 3, NULL);
/*!40000 ALTER TABLE `inventoryitem` ENABLE KEYS */;

-- 프로시저 inventory.inven_delete 구조 내보내기
DELIMITER //
CREATE PROCEDURE `inven_delete`(
	IN `in_item` VARCHAR(50),
	OUT `out_res` INT
)
BEGIN
	DECLARE cnt INT DEFAULT 0;
	SELECT COUNT(*) INTO cnt FROM inventoryitem WHERE item = in_item;
	if cnt > 0 then DELETE FROM inventoryitem WHERE item = in_item;
		SET out_res = 0;
	ELSE SET out_res = 2;
	END if;
END//
DELIMITER ;

-- 프로시저 inventory.inven_insert 구조 내보내기
DELIMITER //
CREATE PROCEDURE `inven_insert`(
	IN `in_category` VARCHAR(50),
	IN `in_brand` VARCHAR(50),
	IN `in_item` VARCHAR(50),
	IN `in_price` INT,
	IN `in_amount` INT
)
BEGIN
	insert into inventoryitem(category, brand, item, price, amount) VALUES(in_category, in_brand, in_item, in_price, in_amount);
END//
DELIMITER ;

-- 프로시저 inventory.inven_select 구조 내보내기
DELIMITER //
CREATE PROCEDURE `inven_select`()
BEGIN
	SELECT * FROM inventoryitem;
END//
DELIMITER ;

-- 프로시저 inventory.inven_update 구조 내보내기
DELIMITER //
CREATE PROCEDURE `inven_update`(
	IN `in_item` VARCHAR(50),
	IN `up_category` VARCHAR(50),
	IN `up_brand` VARCHAR(50),
	IN `up_item` VARCHAR(50),
	IN `up_price` INT,
	IN `up_amount` INT,
	OUT `out_res` INT
)
BEGIN
	DECLARE cnt INT DEFAULT 0;
	SELECT COUNT(*) INTO cnt FROM inventoryitem WHERE item = in_item;
	if cnt > 0 then UPDATE inventoryitem SET category=up_category, brand=up_brand, item=up_item, price=up_price, amount=up_amount WHERE item=in_item;
		SET out_res = 0;
	ELSE SET out_res = 2;
	END if;
END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
